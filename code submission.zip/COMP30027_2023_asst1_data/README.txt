Datset source:
Andrada Olteanu, James Wiltshire, Lauren O’Hare and Minyu Lei. GTZAN Dataset - Music Genre Classification. https://www.kaggle.com/datasets/andradaolteanu/gtzan-dataset-music-genre-classification

Edited for COMP30027 Machine Learning semester 1 2023 The University of Melbourne

First column is the filename of the audio clip from the GZTAN dataset
Columns 2-57 are extracted audio features
Column 58 is the class label